local function fine_print(message, board)
  board = board or "-"
  message = "| " .. tostring(message) .. " |"
  board = board:rep(#message - 2):sub(1, #message)
  print("o" .. board .. "o")
  print(message)
  print("o" .. board .. "o")
end

--fine_print "My test message!"

test = "abc/c ba\\ttt /lua "

print(test:find("(.+)[/\\][^/^\\]+[/\\][^/^\\]+$"))
